#include <iostream>
#include <string>

// Function to extract the message from a log line
std::string line(std::string message) {
    size_t pos = message.find("]: ");
    if (pos != std::string::npos) {
        return message.substr(pos + 3);
    }
    return "";
}

// Function to extract the log level from a log line
std::string level(std::string message) {
    size_t start = message.find("[");
    size_t end = message.find("]:");
    if (start != std::string::npos && end != std::string::npos) {
        return message.substr(start + 1, end - start - 1);
    }
    return "";
}

// Function to reformat a log line
std::string reformat(std::string message) {
    return line(message) + " (" + level(message) + ")";
}

int main() {
    // Print a greeting message
    std::cout << "Good day" << std::endl;

    // Test the line function
    std::cout << "Test for line function:" << std::endl;
    std::cout << "Message extracted: " << line("[ERROR]: Invalid operation") << std::endl; // => "Invalid operation"
    
    // Test the level function
    std::cout << "\nTest for level function:" << std::endl;
    std::cout << "Log level extracted: " << level("[ERROR]: Invalid operation") << std::endl; // => "ERROR"
    
    // Test the reformat function
    std::cout << "\nTest for reformat function:" << std::endl;
    std::cout << "Reformatted log line: " << reformat("[INFO]: Operation completed") << std::endl; // => "Operation completed (INFO)"
    
    return 0;
}
