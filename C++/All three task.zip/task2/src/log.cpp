#include "log.hpp"

Log::Log() {}

Log::~Log() {
    if (file.is_open()) {
        file.close();
    }
}

bool Log::create_log(std::string filename) {
    file.open(filename);
    return file.is_open();
}

bool Log::next() {
    if (std::getline(file, current_line)) {
        return true;
    }
    return false;
}

std::string Log::line() {
    return current_line;
}

std::string Log::level() {
    size_t start = current_line.find("[");
    size_t end = current_line.find("]:");
    if (start != std::string::npos && end != std::string::npos) {
        return current_line.substr(start + 1, end - start - 1);
    }
    return "";
}

std::string Log::reformat() {
    return line() + " (" + level() + ")";
}
