#include <iostream>
#include "log.hpp"

int main() {
    Log log;
    if (!log.create_log("log.in")) {
        std::cout << "Failed to open log file." << std::endl;
        return 1;
    }

    while (log.next()) {
        std::cout << "Original Line: " << log.line() << std::endl;
        std::cout << "Log Level: " << log.level() << std::endl;
        std::cout << "Reformatted Line: " << log.reformat() << std::endl;
    }

    return 0;
}
