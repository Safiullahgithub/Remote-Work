#pragma once

#include <string>
#include <fstream>

class Log {
private:
    std::ifstream file;
    std::string current_line;
public:
    Log();
    ~Log();
    bool create_log(std::string filename);
    bool next();
    std::string line();
    std::string level();
    std::string reformat();
};
