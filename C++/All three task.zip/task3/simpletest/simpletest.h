#pragma once

#include <iostream>
#include <string.h>

#define TEST_MESSAGE(condition, message) \
    do { \
        if (!(condition)) { \
            std::cerr << "Test failed: " << message << std::endl; \
            return false; \
        } else { \
            std::cout << "Test passed: " << message << std::endl; \
        } \
    } while(0)

class Log {
public:
    bool create_log(const char* filename) {
        // Simulate creating a log file
        return true;
    }

    bool next() {
        // Simulate reading the next line
        return true;
    }
};

class TestFixture {
public:
    static bool ExecuteTestGroup(const char* group, bool verbose) {
        // Add your test cases here
        bool result = true;
        if (strcmp(group, "Log") == 0) {
            result &= LogTest1();
            result &= LogTest2();
            result &= LogTest3();
            result &= LogTest4();
            result &= LogTest5();
        }
        return result;
    }

private:
    static bool LogTest1() {
        // Test creating a log file
        Log log;
        bool success = log.create_log("test.log");
        TEST_MESSAGE(success == true, "create_log(\"test.log\")");
        return success;
    }

    static bool LogTest2() {
        // Test reading the next line
        Log log;
        log.create_log("test.log");
        bool success = log.next();
        TEST_MESSAGE(success == true, "next() after create_log(\"test.log\")");
        return success;
    }

    static bool LogTest3() {
        // Test creating a log file with a different name
        Log log;
        bool success = log.create_log("test2.log");
        TEST_MESSAGE(success == true, "create_log(\"test2.log\")");
        return success;
    }

    static bool LogTest4() {
        // Test creating a log file with a long filename
        Log log;
        bool success = log.create_log("this_is_a_very_long_file_name.log");
        TEST_MESSAGE(success == true, "create_log(\"this_is_a_very_long_file_name.log\")");
        return success;
    }

    static bool LogTest5() {
        // Test reading the next line when no log file is created
        Log log;
        bool success = log.next();
        TEST_MESSAGE(success == false, "next() without create_log()");
        return !success;
    }
};
