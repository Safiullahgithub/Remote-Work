#include "simpletest.h"

int main() {
    bool result = TestFixture::ExecuteTestGroup("Log", true);
    if (result) {
        std::cout << "All tests passed." << std::endl;
    } else {
        std::cout << "Some tests failed." << std::endl;
    }
    return result ? 0 : 1;
}
